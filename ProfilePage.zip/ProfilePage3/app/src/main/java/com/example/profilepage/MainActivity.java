package com.example.profilepage;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private static Object FirebaseCrash;
    FloatingActionButton floatingbtn;
    ImageView camera;
    Dialog dialog;
    ImageView gellary;
    ImageView imageView;
    final int ACTIVITY_SELECT_IMAGE = 1234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        floatingbtn = findViewById(R.id.floatingbtn);
        imageView = findViewById(R.id.imageview);

        dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.activity_dialog_box);

        camera = dialog.findViewById(R.id.camera);
        gellary = dialog.findViewById(R.id.gellary);

        floatingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.show();

                Log.e("lalalal", "hello");

            }
        });

        camera.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, 101);

                Log.e("lalalal", "hello");
            }
        });

        gellary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, ACTIVITY_SELECT_IMAGE);

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ACTIVITY_SELECT_IMAGE && resultCode == RESULT_OK && data != null) {

            Bitmap image = (Bitmap) data.getExtras().get("data");
            if (image != null) {
                imageView = findViewById(R.id.imageview);
                imageView.setImageBitmap(image);
            } else {
                Log.e("lalalal", "Failed to retrieve image from camera data.");
            }
            dialog.dismiss();

        } else if (requestCode == ACTIVITY_SELECT_IMAGE && resultCode == RESULT_OK && data != null) {

            Uri selectedImageUri = data.getData();

            try {

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                imageView = findViewById(R.id.imageview);
                imageView.setImageBitmap(bitmap);

            } catch (IOException e) {

                e.printStackTrace();
                Log.e("lalalal", "Failed to retrieve image from gallery.");

            }
            dialog.dismiss();

        } else {
            Log.e("lalalal", "Unexpected result from activity: requestCode=" + requestCode + ", resultCode=" + resultCode);
        }
    }
}